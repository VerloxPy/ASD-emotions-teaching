## Новела «Спокій»: навчальна історія про емоцію «спокій».
## Розмір гри: 1280x720. Результат на сайт надсилає функція send_result.

init python:
    import json

    def send_result(choice, fits):
        if renpy.emscripten:
            message = json.dumps({
                "type": "novel_result",
                "payload": {"choice": choice, "fits": fits},
            })
            renpy.emscripten.run_script(
                "window.parent.postMessage(" + message + ", window.location.origin);"
            )

define lys = Character("Лисичка", color="#FFB366")
define marko = Character("Марко", color="#8EC5FF")
define sofiya = Character("Софійка", color="#FFD966")

transform pos_friend:
    xalign 0.18
    ypos 8

transform pos_fox:
    xalign 0.96
    yalign 1.0

transform pos_prop:
    xpos 640
    ypos 170

label main_menu:
    return

screen novel_end():
    add Solid("#1E2B37")
    text "Кінець історії":
        xalign 0.5
        yalign 0.5
        size 48
        color "#FFFFFF"

label start:
    scene bg_calm with dissolve
    show boy normal at pos_friend with dissolve
    "На перерві ти бачиш Марка. Він сидить на лавці."
    "Марко рівно дихає й дивиться навколо."
    "Плечі в нього розслаблені, а на обличчі легка усмішка."
    show fox thinking at pos_fox with dissolve

    menu:
        lys "Подивися на Марка. Що він відчуває?"

        "Сум":
            "Ти думаєш, що Маркові сумно, і починаєш його втішати: «Не сумуй!»"
            show boy shock with Dissolve(0.3)
            marko "Мені не сумно! Я просто відпочиваю."
            show fox point with Dissolve(0.3)
            lys "Коли сумно, куточки рота опущені. Марко ж має легку усмішку й рівно дихає."
            lys "Подивимося ще раз?"
            $ send_result("sadness", False)
            "Давай спробуємо ще раз з початку."
            jump start

        "Злість":
            "Ти думаєш, що Марко злиться, і обережно відсуваєшся."
            marko "Чому ти так далеко? Сядь поруч."
            "Насправді Марко зараз не злиться."
            show fox point with Dissolve(0.3)
            lys "Коли хтось злиться, брови зведені, а губи стиснуті."
            lys "У Марка обличчя розслаблене."
            $ send_result("anger", False)
            "Давай спробуємо ще раз з початку."
            jump start

        "Спокій":
            "Ти тихо сідаєш поруч."
            marko "Мені тут добре й спокійно. Давай посидимо разом."
            "Ви кілька хвилин спокійно сидите поруч і слухаєте тишу."
            show fox point with Dissolve(0.3)
            lys "Молодець! Спокій можна впізнати."
            lys "Обличчя розслаблене, дихання рівне, а на губах легка усмішка."
            lys "Коли ми хвилюємося, допомагає повільний вдих і видих. Так можна заспокоїтися."
            $ send_result("calm", True)

    call screen novel_end
