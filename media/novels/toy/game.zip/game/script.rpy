﻿init python:
    import json

    def send_result(choice, fits):
        if renpy.emscripten:
            message = json.dumps({
                "type": "novel_result",
                "payload": {"choice": choice, "fits": fits},
            })
            renpy.emscripten.run_script(
                "window.parent.postMessage(" + message + ", window.location.origin);"
            )

label main_menu:
    return

screen novel_end():
    text "Кінець історії":
        xalign 0.5
        yalign 0.5
        size 48

label start:
    "Друг випадково зламав твою іграшку."

    menu:
        "Що ти зробиш?"

        "Скажу, що мені сумно, і попрошу бути обережнішим":
            "Ти спокійно сказав: «Мені сумно, бо це була моя улюблена іграшка»."
            "Друг зніяковів, вибачився і запропонував разом її полагодити."
            "Ти чесно сказав про свої почуття, і друг тебе зрозумів."
            $ send_result("tell_feelings", True)

        "Кину в нього іграшку":
            "Ти кинув іграшку в друга."
            "Друг злякався й заплакав. Тепер ви обидва засмучені, а іграшка зламалася ще більше."
            "Злість тут зрозуміла, але ця реакція не зовсім підходить до ситуації."
            $ send_result("throw_toy", False)
            "Давай спробуємо ще раз з початку."
            jump start

    call screen novel_end