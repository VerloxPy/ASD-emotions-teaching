﻿################################################################################
## Ініціалізація
################################################################################

## Оператор "init offset" змушує оператори ініціалізації у цьому файлі
## виконуватися перед операторами "init" в будь-якому іншому файлі.
init offset = -2

## При виклику "gui.init" стилі відновлюються до розумних стандартних значень, а
## також встановлюються ширина і висота гри.
init python:
    gui.init(1280, 720)

## Увімкнути перевірку на наявність недійсних або нестабільних властивостей в
## екранах або трансформаціях
define config.check_conflicting_properties = True


################################################################################
## Змінні конфігурації інтерфейсу
################################################################################


## Кольори #####################################################################
##
## Кольори тексту в інтерфейсі.

## Акцентний колір інтерфейсу для позначення і підсвічування тексту.
define gui.accent_color = '#99ccff'

## Колір текстової кнопки, коли її не вибрано і не наведено вказівником.
define gui.idle_color = '#888888'

## Малий колір використовується для маленького тексту, який має бути яскравішим/
## темнішим для досягнення того самого ефекту.
define gui.idle_small_color = '#aaaaaa'

## Колір для кнопок і смуг при наведенні вказівником.
define gui.hover_color = '#c1e0ff'

## Колір текстової кнопки, коли її вибрано, але не сфокосовано. Кнопку вибрано,
## якщо вона на поточному екрані або значенням налаштування.
define gui.selected_color = '#ffffff'

## Колір текстової кнопки, коли її неможливо вибрати.
define gui.insensitive_color = '#8888887f'

## Кольори частин смуг, які не заповнені. Вони не використовуються
## безпосередньо, але застосовуються під час повторного створення файлів
## зображень смуг.
define gui.muted_color = '#3d5166'
define gui.hover_muted_color = '#5b7a99'

## Кольори тексту діалогу та меню вибору.
define gui.text_color = '#ffffff'
define gui.interface_text_color = '#ffffff'


## Шрифти та розміри шрифтів ###################################################

## Шрифт для тексту в грі.
define gui.text_font = "DejaVuSans.ttf"

## Шрифт для імен персонажів.
define gui.name_text_font = "DejaVuSans.ttf"

## Шрифт для тексту поза грою.
define gui.interface_text_font = "DejaVuSans.ttf"

## Розмір звичайного тексту діалогу.
define gui.text_size = 22

## Розмір імен персонажів.
define gui.name_text_size = 30

## Розмір тексту в інтерфейсі гри.
define gui.interface_text_size = 22

## Розмір міток в інтерфейсі гри.
define gui.label_text_size = 24

## Розмір тексту на екрані сповіщень.
define gui.notify_text_size = 16

## Розмір назви гри.
define gui.title_text_size = 50


## Головне меню та меню гри ####################################################

## Зображення, використані для головного меню і меню гри.
define gui.main_menu_background = "gui/main_menu.png"
define gui.game_menu_background = "gui/game_menu.png"


## Діалог ######################################################################
##
## Ці змінні визначають, як діалог виводиться на екран по одному рядку.

## Висота текстового поля, що містить діалог.
define gui.textbox_height = 185

## Розташування текстового поля по вертикалі на екрані. 0,0 — верх, 0,5 — центр,
## 1,0 — низ.
define gui.textbox_yalign = 1.0


## Розташування імені персонажа, відносно текстового поля. Значення може бути
## цілим числом пікселів від лівого краю або верхнього краю, або 0,5 до центру.
define gui.name_xpos = 240
define gui.name_ypos = 0

## Горизонтальне вирівнювання імені персонажа. Значення може бути 0,0 для
## вирівнювання по лівому краю, 0,5 по центру і 1,0 по правому краю.
define gui.name_xalign = 0.0

## Ширина, висота та межі поля, що містить ім’я персонажа, або None для
## автоматичного визначення розміру.
define gui.namebox_width = None
define gui.namebox_height = None

## Межі поля, що містить імʼя персонажа, у порядку зліва, зверху, справа, знизу.
define gui.namebox_borders = Borders(5, 5, 5, 5)

## Якщо задано "True", тло поля імені буде мозаїчним. Якщо задано "False", тло
## поля імені буде масштабованим.
define gui.namebox_tile = False


## Розташування діалогу відносно текстового поля. Значення може бути цілим
## числом пікселів відносно лівого або верхнього краю текстового поля, або 0,5
## для вирівнювання по центру.
define gui.dialogue_xpos = 268
define gui.dialogue_ypos = 50

## Максимальна ширина тексту діалогу у пікселях.
define gui.dialogue_width = 744

## Горизонтальне вирівнювання тексту діалогу. Значення може бути 0,0 для
## вирівнювання по лівому краю, 0,5 по центру і 1,0 по правому краю.
define gui.dialogue_text_xalign = 0.0


## Кнопки ######################################################################
##
## Ці змінні, разом із файлами зображень у теці "gui/button", визначають аспекти
## показу кнопок.

## Ширина та висота кнопки у пікселях. Якщо задано "None", Ren'Py обчислюватиме
## розмір.
define gui.button_width = None
define gui.button_height = None

## Межі з кожного боку кнопки в порядку: ліворуч, зверху, праворуч, знизу.
define gui.button_borders = Borders(4, 4, 4, 4)

## Якщо задано "True", зображення тла буде мозаїчним. Якщо задано "False",
## зображення тла буде лінійно масштабуватися.
define gui.button_tile = False

## Шрифт кнопки.
define gui.button_text_font = gui.interface_text_font

## Розмір тексту кнопки.
define gui.button_text_size = gui.interface_text_size

## Колір тексту кнопки у різних станах.
define gui.button_text_idle_color = gui.idle_color
define gui.button_text_hover_color = gui.hover_color
define gui.button_text_selected_color = gui.selected_color
define gui.button_text_insensitive_color = gui.insensitive_color

## Горизонтальне вирівнювання тексту кнопки. (0,0 — ліворуч, 0,5 — по центру,
## 1,0 — праворуч).
define gui.button_text_xalign = 0.0


## Ці змінні замінюють налаштування для різних типів кнопок. Дивіться
## документацію по GUI, щоб дізнатися про типи доступних кнопок та їх
## призначення.
##
## Ці налаштування використовуються стандартним інтерфейсом:

define gui.radio_button_borders = Borders(18, 4, 4, 4)

define gui.check_button_borders = Borders(18, 4, 4, 4)

define gui.confirm_button_text_xalign = 0.5

define gui.page_button_borders = Borders(10, 4, 10, 4)

define gui.quick_button_borders = Borders(10, 4, 10, 0)
define gui.quick_button_text_size = 14
define gui.quick_button_text_idle_color = gui.idle_small_color
define gui.quick_button_text_selected_color = gui.accent_color

## Ви також можете додати власні налаштування, додавши правильно названі змінні.
## Наприклад, ви можете розкоментувати наступний рядок, щоб задати ширину кнопки
## навігації.

# define gui.navigation_button_width = 250


## Кнопки вибору ###############################################################
##
## Кнопки вибору, які використовуються у меню гри.

define gui.choice_button_width = 790
define gui.choice_button_height = None
define gui.choice_button_tile = False
define gui.choice_button_borders = Borders(100, 5, 100, 5)
define gui.choice_button_text_font = gui.text_font
define gui.choice_button_text_size = gui.text_size
define gui.choice_button_text_xalign = 0.5
define gui.choice_button_text_idle_color = '#888888'
define gui.choice_button_text_hover_color = "#ffffff"
define gui.choice_button_text_insensitive_color = '#8888887f'


## Кнопки комірок збережень ####################################################
##
## Кнопка комірки збереження — особливий вид кнопки. Вона містить мініатюру і
## текст, що описує уміст комірки збереження. Комірка збереження використовує
## файли зображень у "gui/button", як і інші типи кнопок.

## Кнопка комірки збереження.
define gui.slot_button_width = 276
define gui.slot_button_height = 206
define gui.slot_button_borders = Borders(10, 10, 10, 10)
define gui.slot_button_text_size = 14
define gui.slot_button_text_xalign = 0.5
define gui.slot_button_text_idle_color = gui.idle_small_color
define gui.slot_button_text_selected_idle_color = gui.selected_color
define gui.slot_button_text_selected_hover_color = gui.hover_color

## Ширина та висота мініатюр, які використовуються комірками збереження.
define config.thumbnail_width = 256
define config.thumbnail_height = 144

## Кількість стовпців і рядків у сітці комірок збереження.
define gui.file_slot_cols = 3
define gui.file_slot_rows = 2


## Позиціонування та інтервал ##################################################
##
## Ці змінні визначають позиціонування та інтервал різних елементів інтерфейсу.

## Позиція лівої сторони навігаційних кнопок відносно лівої сторони екрана.
define gui.navigation_xpos = 40

## Вертикальна позиція індикатора пропуску.
define gui.skip_ypos = 10

## Вертикальна позиція екрана сповіщень.
define gui.notify_ypos = 45

## Інтервал між елементами у меню виборів.
define gui.choice_spacing = 22

## Кнопки в розділі навігації головного меню і меню гри.
define gui.navigation_spacing = 4

## Визначає величину відстані між параметрами.
define gui.pref_spacing = 10

## Визначає відстань між кнопками параметрів.
define gui.pref_button_spacing = 0

## Відстань між кнопками сторінки збережень.
define gui.page_spacing = 0

## Відстань між комірками збережень.
define gui.slot_spacing = 10

## Позиція тексту головного меню.
define gui.main_menu_text_xalign = 1.0


## Рамки #######################################################################
##
## Ці змінні визначають вигляд рамок, які можуть містити компоненти інтерфейсу,
## коли накладення або вікно відсутні.

## Стандартні рамки.
define gui.frame_borders = Borders(4, 4, 4, 4)

## Рамка, яка використовується як частина екрана підтвердження.
define gui.confirm_frame_borders = Borders(40, 40, 40, 40)

## Рамка, яка використовується як частина екрана пропуску.
define gui.skip_frame_borders = Borders(16, 5, 50, 5)

## Рамка, яка використовується як частина екрана сповіщень.
define gui.notify_frame_borders = Borders(16, 5, 40, 5)

## Чи слід тла рамок викласти плиткою?
define gui.frame_tile = False


## Смуги, смуги прокрутки та повзунки ##########################################
##
## Ці визначають вигляд і розмір смуг, смуг прокруток і повзунків.
##
## Стандартний інтерфейс використовує лише повзунки та вертикальні смуги
## прокрутки. Усі інші смуги використовуються лише на екранах, написаних
## автором.

## Висота горизонтальних смуг, смуг прокруток і повзунків. Ширина вертикальних
## смуг, смуг прокруток і повзунків.
define gui.bar_size = 25
define gui.scrollbar_size = 12
define gui.slider_size = 25

## True, якщо зображення смуги мають бути викладено плиткою. False, якщо вони
## повинні бути лінійно масштабовані.
define gui.bar_tile = False
define gui.scrollbar_tile = False
define gui.slider_tile = False

## Горизонтальні межі.
define gui.bar_borders = Borders(4, 4, 4, 4)
define gui.scrollbar_borders = Borders(4, 4, 4, 4)
define gui.slider_borders = Borders(4, 4, 4, 4)

## Вертикальні межі.
define gui.vbar_borders = Borders(4, 4, 4, 4)
define gui.vscrollbar_borders = Borders(4, 4, 4, 4)
define gui.vslider_borders = Borders(4, 4, 4, 4)

## Що робити з не прокручуваними смугами прокрутки у меню гри. Параметр "hide"
## приховує їх, а "None" показує їх.
define gui.unscrollable = "hide"


## Історія #####################################################################
##
## Екран історії показує діалоги, які гравець уже закрив.

## Кількість блоків історії діалогів, які Ren'Py збереже.
define config.history_length = 250

## Висота рядку на екрані історії або "None", щоб зробити висоту змінною шляхом
## швидкодії.
define gui.history_height = 140

## Додатковий простір для додавання між рядком на екрані історії.
define gui.history_spacing = 0

## Позиція, ширина та вирівнювання тексту з іменем персонажа.
define gui.history_name_xpos = 155
define gui.history_name_ypos = 0
define gui.history_name_width = 155
define gui.history_name_xalign = 1.0

## Позиція, ширина та вирівнювання тексту діалогу.
define gui.history_text_xpos = 170
define gui.history_text_ypos = 2
define gui.history_text_width = 740
define gui.history_text_xalign = 0.0


## Режим NVL ###################################################################
##
## Екран режиму NVL показує діалоги, які ведуть персонажі в режимі NVL.

## Межі тла вікна заднього плану режиму NVL.
define gui.nvl_borders = Borders(0, 10, 0, 20)

## Максимальна кількість рядків у режимі NVL, які Ren'Py покаже. Якщо потрібно
## показати більше рядків, найстаріший рядок буде видалено.
define gui.nvl_list_length = 6

## Висота рядку в режимі NVL. Задайте значення "None", щоб рядки динамічно
## регулювали висоту.
define gui.nvl_height = 115

## Відстань між рядками режиму NVL, коли "gui.nvl_height" має значення "None",
## та між рядками режиму NVL і меню режиму NVL.
define gui.nvl_spacing = 10

## Позиція, ширина та вирівнювання тексту з іменем персонажа.
define gui.nvl_name_xpos = 430
define gui.nvl_name_ypos = 0
define gui.nvl_name_width = 150
define gui.nvl_name_xalign = 1.0

## Позиція, ширина та вирівнювання тексту діалогу.
define gui.nvl_text_xpos = 450
define gui.nvl_text_ypos = 8
define gui.nvl_text_width = 590
define gui.nvl_text_xalign = 0.0

##  Позиція, ширина та вирівнювання тексту "nvl_thought" (текст, який вимовляє
##  персонаж "nvl_narrator").
define gui.nvl_thought_xpos = 240
define gui.nvl_thought_ypos = 0
define gui.nvl_thought_width = 780
define gui.nvl_thought_xalign = 0.0

## Позиціонування nvl "menu_buttons".
define gui.nvl_button_xpos = 450
define gui.nvl_button_xalign = 0.0


## Локалізація #################################################################

## Визначає, де дозволений розрив рядка. Стандартне значення підходить
## для більшості мов. Список доступних значень можна знайти на https://
## www.renpy.org/doc/html/style_properties.html#style-property-language

define gui.language = "unicode"


################################################################################
## Мобільні пристрої
################################################################################

init python:

    ## Збільшує розмір кнопок швидкого меню, щоб їх було легше торкатися на
    ## планшетах і телефонах.
    @gui.variant
    def touch():

        gui.quick_button_borders = Borders(40, 14, 40, 0)

    ## Змінює розмір і відстань між різними елементами інтерфейсу, щоб вони були
    ## видимими на телефонах.
    @gui.variant
    def small():

        ## Розміри шрифтів.
        gui.text_size = 30
        gui.name_text_size = 36
        gui.notify_text_size = 25
        gui.interface_text_size = 30
        gui.button_text_size = 30
        gui.label_text_size = 34

        ## Відрегулювати розташування текстового поля.
        gui.textbox_height = 240
        gui.name_xpos = 80
        gui.dialogue_xpos = 90
        gui.dialogue_width = 1100

        ## Змінити розмір і відстань між різними речами.
        gui.slider_size = 36

        gui.choice_button_width = 1240
        gui.choice_button_text_size = 30

        gui.navigation_spacing = 20
        gui.pref_button_spacing = 10

        gui.history_height = 190
        gui.history_text_width = 690

        gui.quick_button_text_size = 20

        ## Макет кнопки збереження.
        gui.file_slot_cols = 2
        gui.file_slot_rows = 2

        ## Режим NVL.
        gui.nvl_height = 170

        gui.nvl_name_width = 305
        gui.nvl_name_xpos = 325

        gui.nvl_text_width = 915
        gui.nvl_text_xpos = 345
        gui.nvl_text_ypos = 5

        gui.nvl_thought_width = 1240
        gui.nvl_thought_xpos = 20

        gui.nvl_button_width = 1240
        gui.nvl_button_xpos = 20
