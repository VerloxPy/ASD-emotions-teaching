## Новела «Здивування»: навчальна історія про емоцію «здивування».
## Розмір гри: 1280x720. Результат на сайт надсилає функція send_result.

init python:
    import json

    def send_result(choice, fits):
        if renpy.emscripten:
            message = json.dumps({
                "type": "novel_result",
                "payload": {"choice": choice, "fits": fits},
            })
            renpy.emscripten.run_script(
                "window.parent.postMessage(" + message + ", window.location.origin);"
            )

define lys = Character("Лисичка", color="#FFB366")
define marko = Character("Марко", color="#8EC5FF")
define sofiya = Character("Софійка", color="#FFD966")

transform pos_friend:
    xalign 0.18
    ypos 8

transform pos_fox:
    xalign 0.96
    yalign 1.0

transform pos_prop:
    xpos 640
    ypos 170

label main_menu:
    return

screen novel_end():
    add Solid("#1E2B37")
    text "Кінець історії":
        xalign 0.5
        yalign 0.5
        size 48
        color "#FFFFFF"

label start:
    scene bg_yard with dissolve
    show boy normal at pos_friend with dissolve
    "Ти граєшся з Марком на подвір’ї. Раптом приходить його тато з коробкою."
    show car_toy at pos_prop with dissolve
    "Марко відкриває коробку. Усередині нова червона машинка!"
    show boy shock with Dissolve(0.3)
    "Марко широко розплющує очі, відкриває рота й каже: 'Ого!' ."
    hide car_toy with dissolve
    show fox thinking at pos_fox with dissolve

    menu:
        lys "Подивися на обличчя Марка. Що він відчуває?"

        "Сум":
            "Ти думаєш, що Маркові сумно, і кажеш: «Не сумуй!»"
            show boy normal with Dissolve(0.3)
            marko "Я не сумую! Я просто дуже здивований."
            "Марко хотів поділитися сюрпризом, а тепер мусить пояснювати."
            show fox point with Dissolve(0.3)
            lys "Коли сумно, куточки рота опущені, а погляд спрямований вниз."
            lys "Марко ж широко розплющив очі й відкрив рота. Подивимося ще раз?"
            $ send_result("sadness", False)
            "Давай спробуємо ще раз з початку."
            jump start

        "Здивування":
            "Ти усміхаєшся: «Ого! Ось це сюрприз!»"
            show boy happy with Dissolve(0.3)
            marko "Я цього зовсім не чекав! Давай пограємося разом!"
            "Спочатку Марко не міг вимовити ні слова, а тепер радісно сміється."
            show fox point with Dissolve(0.3)
            lys "Молодець! Здивування видно одразу."
            lys "Очі широко розплющені, брови підняті, рот відкритий, руки розведені."
            lys "Ми дивуємося, коли трапляється щось несподіване: сюрприз чи нова новина."
            $ send_result("surprise", True)

        "Злість":
            "Ти думаєш, що Марко злиться, і відходиш убік."
            show boy normal with Dissolve(0.3)
            marko "Куди ти? Я хотів показати тобі свою нову машинку!"
            "Ви обидва пропускаєте найцікавіше."
            show fox point with Dissolve(0.3)
            lys "Коли хтось злиться, брови зведені. Марко ж підняв брови й розплющив очі."
            lys "Подивимося ще раз?"
            $ send_result("anger", False)
            "Давай спробуємо ще раз з початку."
            jump start

    call screen novel_end
