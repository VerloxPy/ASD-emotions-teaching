## Новела «Радість»: навчальна історія про емоцію «радість».
## Розмір гри: 1280x720. Результат на сайт надсилає функція send_result.

init python:
    import json

    def send_result(choice, fits):
        if renpy.emscripten:
            message = json.dumps({
                "type": "novel_result",
                "payload": {"choice": choice, "fits": fits},
            })
            renpy.emscripten.run_script(
                "window.parent.postMessage(" + message + ", window.location.origin);"
            )

define lys = Character("Лисичка", color="#FFB366")
define marko = Character("Марко", color="#8EC5FF")
define sofiya = Character("Софійка", color="#FFD966")

transform pos_friend:
    xalign 0.18
    ypos 8

transform pos_fox:
    xalign 0.96
    yalign 1.0

transform pos_prop:
    xpos 640
    ypos 170

label main_menu:
    return

screen novel_end():
    add Solid("#1E2B37")
    text "Кінець історії":
        xalign 0.5
        yalign 0.5
        size 48
        color "#FFFFFF"

label start:
    scene bg_yard with dissolve
    show girl normal at pos_friend with dissolve
    "Ти приходиш на майданчик. Там стоїть Софійка."
    show candy at pos_prop with dissolve
    "Вчителька щойно подарувала їй цукерку за гарну поведінку."
    show girl happy with Dissolve(0.3)
    "Софійка підстрибує, посміхається й голосно сміється."
    hide candy with dissolve
    show fox thinking at pos_fox with dissolve

    menu:
        lys "Подивися уважно на Софійку. Що вона зараз відчуває?"

        "Сум":
            "Ти думаєш, що Софійці сумно, і тихо кажеш: «Не плач, усе буде добре»."
            show girl shock with Dissolve(0.3)
            sofiya "Я не плачу! Я радію!"
            "Софійка хотіла поділитися радістю, а її не зрозуміли."
            show girl sad with Dissolve(0.3)
            "Тепер їй трохи сумно."
            show fox point with Dissolve(0.3)
            lys "Коли сумно, куточки рота опущені, а погляд спрямований вниз."
            show girl happy with Dissolve(0.3)
            lys "А в Софійки широка усмішка й підняті руки. Подивимося ще раз?"
            $ send_result("sadness", False)
            "Давай спробуємо ще раз з початку."
            jump start

        "Радість":
            "Ти усміхаєшся у відповідь: «Ти така щаслива! Що сталося?»"
            show girl happy with Dissolve(0.3)
            sofiya "Мені подарували цукерку! Хочеш, поділюся з тобою?"
            "Ви радієте разом, і вам обом стає ще веселіше."
            show fox point with Dissolve(0.3)
            lys "Молодець! Радість легко впізнати."
            lys "Це усмішка, сміх й веселий голос."
            lys "Коли друг радіє, можна запитати, що сталося, і порадіти разом із ним."
            $ send_result("joy", True)

        "Злість":
            "Ти думаєш, що Софійка злиться, і потихеньку відходиш убік."
            show girl shock with Dissolve(0.3)
            sofiya "Чому ти відходиш? Я хотіла почастувати тебе цукеркою!"
            "Радісна хвилина минає, і вам обом ніяково."
            show fox point with Dissolve(0.3)
            lys "Коли хтось злиться, брови зведені, а губи стиснуті."
            lys "У Софійки усмішка й підняті руки. Це зовсім інше. Спробуймо ще раз?"
            $ send_result("anger", False)
            "Давай спробуємо ще раз з початку."
            jump start

    call screen novel_end
