## Новела «Сум»: навчальна історія про емоцію «сум».
## Розмір гри: 1280x720. Результат на сайт надсилає функція send_result.

init python:
    import json

    def send_result(choice, fits):
        if renpy.emscripten:
            message = json.dumps({
                "type": "novel_result",
                "payload": {"choice": choice, "fits": fits},
            })
            renpy.emscripten.run_script(
                "window.parent.postMessage(" + message + ", window.location.origin);"
            )

define lys = Character("Лисичка", color="#FFB366")
define marko = Character("Марко", color="#8EC5FF")
define sofiya = Character("Софійка", color="#FFD966")

transform pos_friend:
    xalign 0.18
    ypos 8

transform pos_fox:
    xalign 0.96
    yalign 1.0

transform pos_prop:
    xpos 640
    ypos 170

label main_menu:
    return

screen novel_end():
    add Solid("#1E2B37")
    text "Кінець історії":
        xalign 0.5
        yalign 0.5
        size 48
        color "#FFFFFF"

label start:
    scene bg_room with dissolve
    show boy normal at pos_friend with dissolve
    "Ти заходиш до кімнати марка. Він сидить на підлозі."
    show car_toy at pos_prop with dissolve
    "У руках він тримає свою улюблену червону машинку."
    "Колесо відпало, і машинка більше не їздить. Вона зламана."
    show boy sad with Dissolve(0.3)
    "Марко мовчить і дивиться вниз."
    hide car_toy with dissolve
    show fox thinking at pos_fox with dissolve

    menu:
        lys "Подивися на обличчя Марка. Що він відчуває?"

        "Радість":
            "Ти думаєш, що Марко радіє, і весело плескаєш у долоні."
            show boy shock with Dissolve(0.3)
            marko "Чому ти смієшся? Мені так прикро!"
            "Марко відвертається. Тепер йому ще сумніше."
            show fox point with Dissolve(0.3)
            lys "Коли радісно, ми усміхаємося або сміємося."
            lys "Марко ж насупився і дивиться вниз. Подивимося ще раз?"
            $ send_result("joy", False)
            "Давай спробуємо ще раз з початку."
            jump start

        "Сум":
            "Ти сідаєш поруч і тихо кажеш: «Мені шкода, що машинка зламалася»."
            "Ти питаєш: «Хочеш, я посиджу з тобою?»"
            show boy normal with Dissolve(0.3)
            marko "Дякую, що ти поруч. Мені вже трохи легше."
            show fox point with Dissolve(0.3)
            lys "Молодець! Сум можна впізнати."
            lys "Куточки рота опущені, погляд спрямований вниз, голос тихий."
            lys "Коли другові сумно, можна посидіти поруч і сказати добре слово."
            $ send_result("sadness", True)

            
        "Злість":
            "Ти думаєш, що Марко злиться, і суворо кажеш: «Не злись!»"
            show boy mad with Dissolve(0.3)
            marko "Я не злився. Мені було сумно. А тепер я справді сержуся!"
            "Через непорозуміння Маркові стало ще гірше."
            show fox point with Dissolve(0.3)
            lys "Коли хтось злиться, брови зведені, а голос звучить голосніше."
            lys "Марко ж сидів тихо й дивився вниз. Спробуймо ще раз?"
            $ send_result("anger", False)
            "Давай спробуємо ще раз з початку."
            jump start


    call screen novel_end
