## Новела «Злість»: навчальна історія про емоцію «злість».
## Розмір гри: 1280x720. Результат на сайт надсилає функція send_result.

init python:
    import json

    def send_result(choice, fits):
        if renpy.emscripten:
            message = json.dumps({
                "type": "novel_result",
                "payload": {"choice": choice, "fits": fits},
            })
            renpy.emscripten.run_script(
                "window.parent.postMessage(" + message + ", window.location.origin);"
            )

define lys = Character("Лисичка", color="#FFB366")
define marko = Character("Марко", color="#8EC5FF")
define sofiya = Character("Софійка", color="#FFD966")

transform pos_friend:
    xalign 0.18
    ypos 8

transform pos_fox:
    xalign 0.96
    yalign 1.0

transform pos_prop:
    xpos 640
    ypos 170

label main_menu:
    return

screen novel_end():
    add Solid("#1E2B37")
    text "Кінець історії":
        xalign 0.5
        yalign 0.5
        size 48
        color "#FFFFFF"

label start:
    scene bg_room with dissolve
    show girl normal at pos_friend with dissolve
    "Ти заходиш до класу. Софійка стоїть біля свого столу."
    show doodle at pos_prop with dissolve
    "Хтось випадково пролив воду на її малюнок. Він весь розмився."
    show girl mad with Dissolve(0.3)
    "Софійка малювала цей малюнок дуже довго, тож тепер їй неприємно."
    "Вона хмуриться, стискає губи й кладе руки на пояс."
    hide doodle with dissolve
    show fox thinking at pos_fox with dissolve

    menu:
        lys "Подивися на обличчя Софійки. Що вона відчуває?"

        "Злість":
            "Ти спокійно кажеш: «Бачу, що ти сердишся. Мені шкода, що малюнок зіпсувався»."
            show girl normal with Dissolve(0.3)
            sofiya "Так, я розсердилась. Дякую, що ти мене розумієш."
            "Софійка робить глибокий вдих і видих, і злість стихає."
            "Ви разом вирішуєте намалювати новий малюнок."
            show fox point with Dissolve(0.3)
            lys "Молодець! Злість можна впізнати."
            lys "Брови зведені, губи стиснуті, а руки стиснуті в кулаки чи стоять на поясі."
            lys "Злитися нормально. Допомагає глибокий вдих і підтримка."
            $ send_result("anger", True)

        "Радість":
            "Ти думаєш, що Софійка радіє, і весело кажеш: «Який гарний день!»"
            sofiya "Що тут веселого? Мій малюнок зіпсовано!"
            "Тепер Софійка сердиться ще більше."
            show fox point with Dissolve(0.3)
            lys "Коли радісно, ми усміхаємося. Софійка ж хмуриться й стискає губи."
            lys "Подивимося ще раз?"
            $ send_result("joy", False)
            "Давай спробуємо ще раз з початку."
            jump start

        "Спокій":
            "Ти думаєш, що Софійка спокійна, і лишаєшся стояти осторонь."
            show girl sad with Dissolve(0.3)
            "Софійка лишається сама зі своєю злістю. Їй стає ще гірше."
            show fox point with Dissolve(0.3)
            lys "Коли ми спокійні, обличчя розслаблене. А в Софійки зведені брови й стиснуті губи."
            lys "Подивимося ще раз?"
            $ send_result("calm", False)
            "Давай спробуємо ще раз з початку."
            jump start

    call screen novel_end
